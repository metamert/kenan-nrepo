import React from "react";

import HomeBox from "../components/Home/select";

const Home = (props) => {
  

  return (
  
      <HomeBox></HomeBox>
  
  );
};

export default Home;

/**
 * 
           <Lottie
            style={{zIndex:-1}}
            options={defaultOptions}
            height={400}
            width={400}
        
          />
 */
