

export const setCurrentUser = user => ({
  type: "setUser",
  payload: user
});



export const setAdmin = admin => ({
  type: "setAdmin",
  payload: admin
});