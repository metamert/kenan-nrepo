import express, { Request, Response } from 'express';
import { AuthController } from '../controllers/authController';
import { jwtController } from '../controllers/jwtTokenController';

export const router = express.Router({
    strict: true
});

const auth=new AuthController()
const jwt =new jwtController()

router.post('/register', (req: Request, res: Response) => {
    console.log("auth/register")
    auth.register(req, res);
});




router.post('/login', (req: Request, res: Response) => {
    auth.login(req, res);
});

router.post('/adminLogin', (req: Request, res: Response) => {
    auth.adminLogin(req, res);
});

router.post('/verify', (req: Request, res: Response) => {
    jwt.authorize(req, res);
});