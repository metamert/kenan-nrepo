import express, { Request, Response } from 'express';
import { userController } from '../controllers';

export const router = express.Router({
    strict: true
});


router.post('/payment', (req: Request, res: Response) => {
    userController.buyTicket(req, res);
});

router.get('/', (req: Request, res: Response) => {
    
    userController.read(req, res);
});
router.get('/myTickets', (req: Request, res: Response) => {
   
  userController.getMyTickets(req, res);
});
router.get('/bookings', (req: Request, res: Response) => {
   
  userController.getBookings(req, res);
});


router.delete('/', (req: Request, res: Response) => {
    userController.delete(req, res);
});