import { router as userRouter } from './User';
import { router as authRouter} from "./auth"
import { router as busRouter} from "./bus"
import { router as tripRouter} from "./trip"
import { router as statisticRouter} from "./statistic"
export {
    userRouter,
    authRouter,
    busRouter,
    tripRouter,
    statisticRouter
};