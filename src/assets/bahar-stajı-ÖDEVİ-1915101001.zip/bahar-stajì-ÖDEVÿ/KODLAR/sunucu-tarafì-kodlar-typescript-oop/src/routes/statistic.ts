import express, { Request, Response } from 'express';
import { statisticRouter } from '.';
import { StatisticController} from '../controllers/statisticController';

export const router = express.Router({
    strict: true
});

const statistic=new StatisticController()


router.get('/alldata', (req: Request, res: Response) => {

    statistic.getAllData(req, res);
});

