import express, { Request, Response } from 'express';
import { TripController} from '../controllers/tripController';

export const router = express.Router({
    strict: true
});

const trip=new TripController()


router.get('/', (req: Request, res: Response) => {
  
    trip.read(req, res);
});
router.get('/query', (req: Request, res: Response) => {
  
    trip.readQuery(req, res);
});

router.post('/', (req: Request, res: Response) => {
    trip.add(req, res);
});

router.put('/', (req: Request, res: Response) => {
    trip.update(req, res);
});

router.delete('/', (req: Request, res: Response) => {
    trip.delete(req, res);
});