import express, { Request, Response } from 'express';
import { BusController} from '../controllers/busController';

export const router = express.Router({
    strict: true
});

const bus=new BusController()


router.get('/', (req: Request, res: Response) => {
  
    bus.read(req, res);
});

router.post('/', (req: Request, res: Response) => {
    bus.add(req, res);
});

router.put('/', (req: Request, res: Response) => {
    bus.update(req, res);
});

router.delete('/', (req: Request, res: Response) => {
    bus.delete(req, res);
});