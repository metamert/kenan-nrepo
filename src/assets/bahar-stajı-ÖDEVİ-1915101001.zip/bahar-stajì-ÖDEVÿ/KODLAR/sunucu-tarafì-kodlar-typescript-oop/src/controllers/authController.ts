import { Request, Response } from "express";
import { connect } from "../database/mysql";
import bcrypt from "bcrypt";
require("dotenv").config();
import {jwtController} from "./jwtTokenController"

const jwt=new jwtController()

export class AuthController {
  public async register(req: Request, res: Response) {
 
    const { email, name, lastName, password, phoneNumber, tin ,hes} = req.body;

    console.log("register *", req.body);

    try {
      const pool = await connect();

      const [
        users,
        fields,
      ] = await pool.execute("SELECT * FROM users WHERE email = ?", [email]);
      let users_row: any = users;
      if (users_row.length) {
        return res.status(401).json("User already exist!");
      }

      const salt = await bcrypt.genSalt(10);
      const bcryptPassword = await bcrypt.hash(password, salt);

      let newUser = await pool.execute(
        "INSERT INTO users (email,name, lastName, password,phoneNumber,tin,hes) VALUES (?, ?,?,?,?,?,?) ",
        [email, name, lastName, bcryptPassword, phoneNumber, tin,hes]
      );

      const [
        newUs,
        fields2,
      ] = await pool.execute("SELECT * FROM users WHERE email = ?", [email,bcryptPassword]);
      console.log(newUser)
      return res.json({ user: newUs, status: true });
      
    } catch (err) {
      console.log(err)
     return res.status(500).send(err.message);
    }
  }
  public async adminLogin(req: Request, res: Response){
   

    try {
      const { email, password } = req.body;
    
      const pool = await connect();


      const [
        admins,
        fields,
      ] = await pool.execute("SELECT * FROM admins WHERE email = ?", [email]);
      let admins_row: any = admins;
      console.log(admins_row.length)
      if (!admins_row.length) {
        return res.status(401).json("Böyle bir email bulunmamaktadır");
      }

      const validPassword = password==admins_row[0].password
      

      if (!validPassword) {
        return res.status(401).json("email veya parola yanlış");
      }
      let token= jwt.jwtGenerator({admin:email,password:password,role:"admin"});
     return res.json({ admin: {...admins_row[0],jwt_token:token }, status: true,});
    } catch (err) {
      console.error(err.message);
      res.status(500).send(err.message);
      
    }
  }
  
  public async login(req: Request, res: Response) {
  

    try {
      const pool = await connect();
      const { user_email, user_password } = req.body;
 
     const email=user_email
     const password=user_password

     
      const [
        users,
        fields,
      ] = await pool.execute("SELECT * FROM users WHERE email = ?", [email]);
      let users_row: any = users;
      console.log(users_row.length)
      if (!users_row.length) {
        return res.status(401).json("Böyle bir email bulunmamaktadır");
      }

      const validPassword = await bcrypt.compare(
        password,
        users_row[0].password
      );

      
      if (!validPassword) {
        return res.status(401).json("email veya parola yanlış");
      }
console.log(users_row[0])
      return res.json({ user: users_row[0], status: true });
    } catch (err) {
      console.error(err.message);
     return res.status(500).send(err.message);
    }
  }

}
