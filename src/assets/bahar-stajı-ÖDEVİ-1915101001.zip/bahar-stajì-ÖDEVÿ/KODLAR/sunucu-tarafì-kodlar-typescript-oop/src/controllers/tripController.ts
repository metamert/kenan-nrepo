import { Request, Response } from "express";
import { CrudController } from "./crudController";
import { connect } from "../database/mysql";
import {jwtController} from "./jwtTokenController"

const jwt=new jwtController()

export class TripController extends CrudController {
  public async add(req: Request, res: Response){
    jwt.authorize(req,res)
    try {
      let { departureFrom,arrivalIn,departure,busId,price} = req.body;
      departure=new Date(departure)
      const pool = await connect();
   
      const [data,_] = await pool.execute(
        "INSERT INTO trips (departureFrom,arrivalIn,departure,busId,price) VALUES (?,?,?,?,?)",
        [ departureFrom,arrivalIn,departure,busId,price]
      );
       

     return res.status(200).json({ data: data ,status:true});
    } catch (error) {
      return res.status(500).json({ error:error.message ,status:false});
    }
  }

  public async readQuery(req: Request, res: Response) {
    
    try {
      const pool = await connect();
      console.log("querry", req.query)
      let { departureFrom,arrivalIn,departure} = req.query;
    
  let dep:any=departure
  let new_dep=new Date(dep)
let next_dep=new Date(new Date(dep).setDate(new_dep.getDate()+1))
let before_dep=new Date(new Date(dep).setDate(new_dep.getDate()-1))

   
      const [data,_] = await pool.execute("SELECT * FROM `trips`  INNER JOIN `bus`  ON trips.busId = bus.id WHERE trips.departureFrom = ? AND trips.arrivalIn = ? AND  trips.departure >= ? AND trips.departure <? ",[departureFrom,arrivalIn,before_dep,next_dep]);
    return  res.status(200).json({ data: data });
    } catch (error) {
      console.log(error)
      return res.status(500).json({ error:error.message ,status:false});
    }
 
  }

 
  public async read(req: Request, res: Response) {
    jwt.authorize(req,res)
     
      try {
        const pool = await connect();
        let { departureFrom,arrivalIn,departure} = req.body;
        departure=new Date(departure)
        const [data,_] = await pool.execute("SELECT * FROM `trips` ");
      return  res.status(200).json({ data: data });
      } catch (error) {
        return res.status(500).json({ error:error.message ,status:false});
      }
    }
   
  



  public async update(req: Request, res: Response){
    jwt.authorize(req,res)
    let { departureFrom,arrivalIn,departure,busId,price,tripId} = req.body;
    departure=new Date(departure)
    try {
      const pool = await connect();
   
      const [data,_] = await pool.execute(
        "UPDATE trips SET departureFrom=?,arrivalIn=?,departure=?,busId=?,price=? WHERE tripId=?",
        [ departureFrom,arrivalIn,departure,busId,price,tripId]
      );
      
    return  res.status(200).json({ data: data ,status:true});
    } catch (error) {
       return res.status(500).json({ error:error.message ,status:false});
    }
  }

  
  public async delete(req: Request, res: Response){
    jwt.authorize(req,res)
    try {
      const { id} = req.body;
    
      const pool = await connect();
   
      const [data,_] = await pool.execute(
        "DELETE FROM trips WHERE tripId=?",
        [ id]
      );
      
   return res.status(200).json({ data: data ,status:true});
    } catch (error) {
     return   res.status(500).json({ error:error.message ,status:false});
    }
  }
}
