import { Request, Response } from "express";
import { connect } from "../database/mysql";
import bcrypt from "bcrypt";
import {jwtController} from "./jwtTokenController"

const jwt=new jwtController()
   

export class StatisticController {
  public async getAllData(req: Request, res: Response) {
   
    jwt.authorize(req,res)


    try {
      const pool = await connect();
  
     let from:any=req.query.from
     let to:any=req.query.to
     from=new Date(from)
     to=new Date(to)
      const [
        tickets,
        fields,
      ] = await pool.execute("SELECT * FROM `tickets` INNER JOIN `trips`  ON trips.tripId = tickets.tripId INNER JOIN `users`  ON users.id = tickets.userId INNER JOIN `transactions`  ON transactions.ticketId = tickets.Id WHERE  tickets.createdAt BETWEEN ? AND ?",[from,to]);
      const [
        users,
        fields3,
      ] = await pool.execute("SELECT * FROM `users` WHERE createdAt BETWEEN ? AND ?",[from,to]);
      
      const [
        bus,
        fields4,
      ] = await pool.execute("SELECT * FROM `bus`  WHERE createdAt BETWEEN ? AND ?",[from,to]);
      const [
        trips,
        fields5,
      ] = await pool.execute("SELECT * FROM `trips` WHERE createdAt BETWEEN ? AND ?",[from,to]);



      return res.status(200).json({ all_data: {tickets:tickets,datas:{users:users,bus:bus,trips:trips}}, status: true });
    } catch (err) {
      console.error(err.message);
     return res.status(500).send("server error");
    }
  }
  
}
