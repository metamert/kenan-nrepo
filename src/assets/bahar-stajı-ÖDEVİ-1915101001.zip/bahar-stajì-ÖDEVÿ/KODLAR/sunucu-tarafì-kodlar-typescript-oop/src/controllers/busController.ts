import { Request, Response } from "express";
import { CrudController } from "./crudController";
import { connect } from "../database/mysql";
import {jwtController} from "./jwtTokenController"

const jwt=new jwtController()


export class BusController extends CrudController {
  public async add(req: Request, res: Response){
    
    jwt.authorize(req,res)

    const { name,busType, wifi, foodService, tv} = req.body;
    console.log(req.body)
    try {
      const pool = await connect();
   
      const [data,_] = await pool.execute(
        "INSERT INTO bus (name,busType, wifi, foodService, tv) VALUES (?,?,?,?,?)",
        [ name,busType, wifi, foodService, tv]
      );
      
    return  res.status(200).json({ data: data ,status:true});
    } catch (error) {
       return res.status(500).json({ error:error.message ,status:false});
    }
  }

  public async read(req: Request, res: Response) {
    jwt.authorize(req,res)
    try {
      const pool = await connect();

      const [data,_] = await pool.execute("SELECT * FROM `bus` ");
      res.status(200).json({ data: data });
    } catch (error) {
      return res.status(500).json({ error:error.message ,status:false});
    }
  }

  public async update(req: Request, res: Response){
   
    jwt.authorize(req,res)
    try {
      const { id,name,busType, wifi, foodService, tv} = req.body;
      const pool = await connect();
   
      const [data,_] = await pool.execute(
        "UPDATE bus SET name=?,busType=?,wifi=?,foodService=?,tv=? WHERE id=?",
        [ name,busType, wifi, foodService, tv,id]
      );
      
     return res.status(200).json({ data: data ,status:true});
    } catch (error) {
      return res.status(500).json({ error:error.message ,status:false});
    }
  }

  public async delete(req: Request, res: Response){
    const { id} = req.body;
    jwt.authorize(req,res)
    console.log(id)
    try {
      const pool = await connect();
   
      const [data,_] = await pool.execute(
        "DELETE FROM bus WHERE id=?",
        [ id]
      );
      
     return res.status(200).json({ data: data ,status:true});
    } catch (error) {
      return res.status(500).json({ error:error.message ,status:false});
    }
  }
}
