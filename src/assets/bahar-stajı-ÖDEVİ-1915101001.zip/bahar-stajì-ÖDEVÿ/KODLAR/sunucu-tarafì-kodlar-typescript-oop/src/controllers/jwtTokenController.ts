import { Request, Response } from "express";

const jwt = require("jsonwebtoken");
require("dotenv").config();

//this middleware will on continue on if the token is inside the local storage

export class jwtController {
  public async authorize(req: Request, res: Response) {
    // Check if not token

    const token = req.header("jwt_token");

    if (!token) {
      return res.status(403).json({ err: "token geçerli değil" });
    }

    // Verify token
    try {
      //it is going to give use the user id (user:{id: user.id})
      const verify = jwt.verify(token, process.env.jwtSecret);
    } catch (err) {
      res.status(401).json({ err: "token geçerli değil !" });
      return;
    }
  }

  public jwtGenerator(payload: any) {
    //{user_id:admin_email,password:admin_password,role:"admin"}
    return jwt.sign(payload, process.env.jwtSecret);
  }
}
