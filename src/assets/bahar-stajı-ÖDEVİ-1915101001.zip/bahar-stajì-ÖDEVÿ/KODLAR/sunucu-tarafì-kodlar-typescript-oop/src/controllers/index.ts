import { UserController } from './userController';

const userController = new UserController();

export {
    userController
};