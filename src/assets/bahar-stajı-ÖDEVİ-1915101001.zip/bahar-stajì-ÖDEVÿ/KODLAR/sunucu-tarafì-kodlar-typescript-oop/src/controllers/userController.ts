import { Request, Response } from "express";
import { CrudController } from "./crudController";
import { connect } from "../database/mysql";
import Stripe from "stripe";
const secret: any = process.env.STRIPE_SECRET_KEY;
const stripe = require("stripe")(
  secret);

import { jwtController } from "./jwtTokenController";
const jwt = new jwtController();

export class UserController {


  public async delete(req: Request, res: Response) {
    try {
      const pool = await connect();
      const { id } = req.query;
      jwt.authorize(req, res);
      console.log(id);

      const [data, _] = await pool.execute("DELETE FROM users WHERE id=?", [
        id,
      ]);

      return res.status(200).json({ data: data, status: true });
    } catch (error) {
      return res.status(500).json({ error: error.message, status: false });
    }
  }

  public async read(req: Request, res: Response): Promise<void> {
    try {
      const pool = await connect();

      const users = await pool.execute("SELECT * FROM `users` ");
      res.status(200).json({ users: users[0] });
    } catch (error) {
      console.log("error", error);
    }
  }

  public async buyTicket(req: Request, res: Response) {
    const { userId, tripId, amount, seat, token } = req.body;
    console.log("bodyy", req.body);
    console.log("seattt", seat);
    const body = {
      source: req.body.token.id,
      amount: amount,
      currency: "TRY",
    };

    stripe.charges.create(body, async (stripeErr: any, stripeRes: any) => {
      if (stripeErr) {
        console.log(stripeErr);
        res.status(500).send({ error: stripeErr });
      } else {
        try {
          const insurance = true;
          const pool = await connect();

          const [
            data,
            _,
          ] = await pool.execute(
            "INSERT INTO tickets (userId,tripId,price,insurance,seat) VALUES (?,?,?,?,?)",
            [userId, tripId, amount, insurance, seat]
          );
          let insertId: any = data;
          console.log("data", insertId);
          await pool.execute(
            "INSERT INTO transactions (ticketId,method,tax,adress) VALUES (?,?,?,?)",
            [insertId.insertId, "visa", "18%", token.card.address_line1]
          );

          return res.status(200).json({ data: data, status: true });
        } catch (error) {
          console.log(error);
          return res.status(500).json({ error: error.message, status: false });
        }
      }
    });
  }

  public async getMyTickets(req: Request, res: Response) {
    try {
      const { id } = req.query;
      console.log("id", id);
      const pool = await connect();

      const [
        data,
        _,
      ] = await pool.execute(
        "SELECT * FROM `tickets` INNER JOIN `trips`  ON trips.tripId = tickets.tripId INNER JOIN `users`  ON users.id = tickets.userId WHERE userId=?",
        [id]
      );
      let data_row: any = data;
      delete data_row[0].password;
      console.log(data_row);
      res.status(200).json({ data: data_row });
    } catch (error) {
      return res.status(500).json({ error: error.message, status: false });
    }
  }

  public async getBookings(req: Request, res: Response) {
    try {
      const { id } = req.query;
      console.log("id", id);
      const pool = await connect();

      const [
        data,
        _,
      ] = await pool.execute("SELECT * FROM `tickets`  WHERE tripId=?", [id]);

      res.status(200).json({ data: data });
    } catch (error) {
      return res.status(500).json({ error: error.message, status: false });
    }
  }
}
