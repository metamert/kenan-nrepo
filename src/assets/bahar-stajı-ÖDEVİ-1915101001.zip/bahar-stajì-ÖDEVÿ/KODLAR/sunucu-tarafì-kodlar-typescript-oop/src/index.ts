import express from 'express';

import { userRouter,authRouter,busRouter,tripRouter,statisticRouter} from './routes';
import {connect} from "./database/mysql"
import cors from "cors"
import 'dotenv/config'
const PORT=3000
const app = express();


//middleware

app.use(cors());

app.use(express.json());

app.use('/users', userRouter);
app.use('/bus', busRouter);
app.use('/trip', tripRouter);
app.use('/auth', authRouter);
app.use('/statistic', statisticRouter);

app.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
  
connect().then((e)=>console.log("success",e)).catch(e=>console.log("error",e))
});